from pathlib import Path
from functools import lru_cache

from faster_whisper import WhisperModel


@lru_cache(maxsize=1)
def get_model():
    # "small" is a practical default for a laptop.
    # Change to "base" for faster/lighter processing or "medium" for better accuracy.
    return WhisperModel("small", device="cpu", compute_type="int8")


def transcribe_audio(audio_path: Path):
    model = get_model()
    segments, info = model.transcribe(
        str(audio_path),
        beam_size=5,
        vad_filter=True,
    )

    text_parts = []
    for segment in segments:
        text = segment.text.strip()
        if text:
            text_parts.append(text)

    return " ".join(text_parts), info.language
