from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.units import mm


def create_pdf(pdf_path: Path, original_filename: str, language: str,
               transcript: str, summary: str):
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "TitleCustom",
        parent=styles["Title"],
        alignment=TA_CENTER,
        spaceAfter=12,
    )

    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
    )

    story = [
        Paragraph("Multilingual Meeting Notes", title),
        Paragraph(f"<b>Source:</b> {original_filename}", styles["BodyText"]),
        Paragraph(f"<b>Detected language:</b> {language}", styles["BodyText"]),
        Spacer(1, 10),
        Paragraph("Summary", styles["Heading2"]),
        Paragraph(summary.replace("\n", "<br/>"), styles["BodyText"]),
        Spacer(1, 12),
        Paragraph("Transcript", styles["Heading2"]),
        Paragraph(transcript.replace("\n", "<br/>"), styles["BodyText"]),
    ]

    doc.build(story)
