import re
from collections import Counter

STOPWORDS = {
    "the", "and", "for", "that", "this", "with", "from", "have", "are",
    "was", "were", "will", "would", "there", "their", "about", "into",
    "your", "you", "they", "them", "then", "than", "what", "when",
    "where", "which", "while", "also", "been", "being", "has", "had",
    "but", "not", "can", "could", "should", "our", "out", "all", "any",
    "a", "an", "to", "of", "in", "on", "is", "it", "as", "at", "by"
}


def _sentences(text):
    return [
        s.strip()
        for s in re.split(r"(?<=[.!?।])\s+", text)
        if len(s.strip()) > 20
    ]


def summarize_text(text, max_sentences=5):
    """
    Lightweight extractive summarizer.
    It requires no API key and works offline after transcription.
    """
    sentences = _sentences(text)
    if len(sentences) <= max_sentences:
        return " ".join(sentences)

    words = re.findall(r"[A-Za-z']+", text.lower())
    frequencies = Counter(w for w in words if w not in STOPWORDS and len(w) > 2)

    scored = []
    for index, sentence in enumerate(sentences):
        sentence_words = re.findall(r"[A-Za-z']+", sentence.lower())
        score = sum(frequencies[w] for w in sentence_words)
        scored.append((score, index, sentence))

    selected = sorted(scored, reverse=True)[:max_sentences]
    selected = sorted(selected, key=lambda item: item[1])
    return " ".join(item[2] for item in selected)
