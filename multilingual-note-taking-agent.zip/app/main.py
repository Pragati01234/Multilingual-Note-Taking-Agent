from pathlib import Path
import shutil
import uuid

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.services.transcriber import transcribe_audio
from app.services.summarizer import summarize_text
from app.services.pdf_exporter import create_pdf

BASE_DIR = Path(__file__).resolve().parent.parent
UPLOAD_DIR = BASE_DIR / "storage" / "uploads"
OUTPUT_DIR = BASE_DIR / "storage" / "outputs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="Multilingual Note-Taking Agent",
    description="Upload audio, transcribe it with Whisper, summarize the transcript, and export a PDF.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=BASE_DIR / "app" / "static"), name="static")


@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE_DIR / "app" / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/process")
async def process_audio(file: UploadFile = File(...)):
    allowed = {".wav", ".mp3", ".m4a", ".mp4", ".webm", ".ogg", ".flac"}
    suffix = Path(file.filename or "").suffix.lower()

    if suffix not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type. Use: {', '.join(sorted(allowed))}",
        )

    job_id = uuid.uuid4().hex
    input_path = UPLOAD_DIR / f"{job_id}{suffix}"

    with input_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        transcript, language = transcribe_audio(input_path)
        if not transcript.strip():
            raise HTTPException(status_code=422, detail="No speech could be detected.")

        summary = summarize_text(transcript)
        pdf_path = OUTPUT_DIR / f"{job_id}.pdf"
        create_pdf(
            pdf_path=pdf_path,
            original_filename=file.filename or "audio",
            language=language,
            transcript=transcript,
            summary=summary,
        )

        return {
            "job_id": job_id,
            "filename": file.filename,
            "language": language,
            "transcript": transcript,
            "summary": summary,
            "pdf_url": f"/api/download/{job_id}",
        }
    finally:
        # Keep the generated PDF, but remove the uploaded audio after processing.
        input_path.unlink(missing_ok=True)


@app.get("/api/download/{job_id}")
def download_pdf(job_id: str):
    pdf_path = OUTPUT_DIR / f"{job_id}.pdf"
    if not pdf_path.exists():
        raise HTTPException(status_code=404, detail="PDF not found.")
    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        filename=f"meeting-notes-{job_id}.pdf",
    )
