from app.services.summarizer import summarize_text


def test_summary_returns_text():
    text = (
        "The team discussed the new release today. "
        "The release includes API improvements and better logging. "
        "Testing will begin tomorrow. "
        "The production deployment is planned for Friday. "
        "The team will monitor the service after deployment. "
        "Documentation will be updated before release."
    )
    result = summarize_text(text, max_sentences=3)
    assert result
    assert len(result) > 20
